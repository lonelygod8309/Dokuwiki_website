<?php

// Fallback script for compatibility with Bootstrap Wrapper and Icons plugins

include_once(template('/tpl/global.php'));
